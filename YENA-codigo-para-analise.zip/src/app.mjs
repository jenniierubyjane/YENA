import {PLANS,PRICES,money,escapeHtml as esc,calculateQuote,quoteText,normalize,parseQuote,seedClients,validateClient} from './core.mjs';
import {clientRoutes,customerPage,invitesPage,inviteToken,quoteStatuses,receptionPanel,setupPublicQuote,simulateMotion,startWebcam,stopWebcam,webcamPanel} from './portal.mjs';

const paths={
 home:'M3 10l9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z',
 camera:'M15 8l6-3v14l-6-3M4 6h9a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z',
 sparkle:'M12 3l2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5zM20 2v4M18 4h4',
 users:'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M16 3a4 4 0 0 1 0 8M22 21v-2a4 4 0 0 0-3-3.87M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
 document:'M14 2H5a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V9zM14 2v7h7M7 13h10M7 17h7',
 settings:'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8M9 3l1-1h4l1 3 3 1 3 2-1 3v2l1 3-3 2-3 1-1 3h-4l-1-3-3-1-3-2 1-3v-2L3 8l3-2 3-1z',
 arrow:'M5 12h14M13 6l6 6-6 6',
 chevron:'M9 5l7 7-7 7',
 info:'M12 11v6M12 7h.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',
 shield:'M12 2l9 4v6c0 5-9 10-9 10S3 17 3 12V6zM8 12l3 3 5-6',
 alert:'M10.3 3.8L1.8 18.5A1.7 1.7 0 0 0 3.3 21h17.4a1.7 1.7 0 0 0 1.5-2.5L13.7 3.8a2 2 0 0 0-3.4 0zM12 9v4M12 17h.01',
 cube:'M12 2l10 5.5v9L12 22 2 16.5v-9zM2 7.5l10 6 10-6M12 13.5V22M7 4.7l10 6',
 eye:'M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12zM15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0',
 plus:'M12 5v14M5 12h14',
 close:'M6 6l12 12M18 6L6 18',
 menu:'M4 6h16M4 12h16M4 18h16',
 search:'M21 21l-5-5M18 10a8 8 0 1 1-16 0 8 8 0 0 1 16 0',
 edit:'M15 5l4 4M12 8l5-5a2.8 2.8 0 0 1 4 4L9 19l-6 2 2-6z',
 trash:'M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7',
 download:'M12 3v12M7 10l5 5 5-5M4 16v5h16v-5',
 send:'M22 2L9 15M22 2l-6 20-4-10L2 8z',
 check:'M5 12l4 4L19 6',
 offline:'M3 3l18 18M16 8l5-3v14M4 6h8M15 15v2H3V6',
 reset:'M3 10a9 9 0 1 1 2 8M3 3v7h7',
 heart:'M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z'
};
const icon=(name,cls='')=>`<svg class="icon ${cls}" viewBox="0 0 24 24" aria-hidden="true"><path d="${paths[name]||paths.info}"/></svg>`;
const routes=[['inicio','Início','home'],['clientes','Clientes','users'],['orcamentos','Orçamentos','document'],['monitoramento','Câmeras','camera'],['convites','Convites','shield'],['ai','YENA AI','sparkle'],['configuracoes','Configurações','settings']];
const rooms=[{id:'recepcao',name:'Recepção',code:'CAM 01',online:true},{id:'corredor',name:'Corredor principal',code:'CAM 02',online:true},{id:'convivencia',name:'Sala de convivência',code:'CAM 03',online:true},{id:'acesso',name:'Acesso principal',code:'CAM 04',online:false}];
const alerts=[
 {id:'a1',title:'Movimentação fora do horário',room:'corredor',time:'14:32',priority:'Alta',description:'Cenário fictício: movimentação em uma área configurada para demonstrar um alerta de prioridade alta. Nenhuma imagem foi capturada ou analisada.',context:'Este exemplo mostra como uma equipe poderia revisar um evento. Não representa uma ocorrência real.'},
 {id:'a2',title:'Conexão indisponível',room:'acesso',time:'14:20',priority:'Média',description:'Cenário fictício: a câmera demonstrativa do acesso principal aparece como desconectada. Não existe câmera física vinculada ao protótipo.',context:'O estado serve apenas para demonstrar o tratamento visual de uma indisponibilidade.'},
 {id:'a3',title:'Verificação de ambiente',room:'recepcao',time:'13:48',priority:'Baixa',description:'Cenário fictício: lembrete para revisar o ambiente de recepção. O evento é pré-definido e não resulta de detecção automática.',context:'Você pode marcar este exemplo como revisado. A alteração vale apenas nesta sessão.'}
];
let clients=seedClients(), reviewed=new Set(),route='',toastTimer, quoteInput={plan:'profissional',cameras:4,badges:20,installation:true,maintenance:true};
let monitorFilters={room:'todos',priority:'todas'},clientFilters={search:'',stage:'todas'},reducedMotion=false;
let messages=[{role:'assistant',text:'Olá! Eu sou a YENA AI, em versão demonstrativa.\n\nPosso apresentar a YENA, consultar a tabela acadêmica de preços, calcular estimativas e organizar fichas dos clientes desta sessão. Minhas respostas são geradas por regras locais; nenhum modelo externo é consultado.\n\nComo posso ajudar?'}];
const demoGreeting=messages[0].text;
let aiConnection={configured:false,model:'',available:false},aiMode='demo',chatBusy=false,chatController=null,chatVersion=0;
let dataConnection={configured:false,ready:false,authenticated:false,user:null,accessConfigured:false},savedQuotes=[],quoteClientId='';
let authState={checked:false,authenticated:false,available:false,accessConfigured:false,message:''},authVersion=0;
let clientPortal=null,clientPortalError='',accounts=null,accountsError='';
const isClient=()=>dataConnection.user?.role==='client';
const main=document.querySelector('#main'),dialog=document.querySelector('#dialog');
document.querySelector('#login-brand').innerHTML=document.querySelector('.sidebar .brand').innerHTML.replaceAll('logo-orbit','login-logo-orbit');
document.querySelector('#public-brand').innerHTML=document.querySelector('.sidebar .brand').innerHTML.replaceAll('logo-orbit','public-logo-orbit');
document.querySelector('#public-art').innerHTML=hospitalArt().replaceAll('art-floor','public-art-floor').replaceAll('art-wall','public-art-wall');
document.querySelectorAll('[data-public-icon]').forEach(element=>{element.innerHTML=icon(element.dataset.publicIcon);});
document.querySelector('.password-toggle').innerHTML=icon('eye');
document.querySelector('#login-lock').innerHTML=icon('shield');
document.querySelector('#menu-toggle').innerHTML=icon('menu');
function renderNav(availableRoutes){document.querySelector('#nav').innerHTML=availableRoutes.map(([id,label,i])=>`<a class="nav-link" href="#${id}" data-route="${id}">${icon(i)}<span>${label}</span>${id==='ai'?'<span class="nav-small">DEMO</span>':''}</a>`).join('');}
function heading(title,subtitle,action=''){return `<div class="page-heading"><div><h1>${title}</h1><p>${subtitle}</p></div>${action}</div>`;}
function notice(text,warm=false){return `<div class="notice${warm?' warm':''}">${icon('info')}<div>${text}</div></div>`;}
function toast(message){const el=document.querySelector('#toast');el.textContent=message;el.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.hidden=true,4200);}
async function apiJSON(url,options={}){const response=await fetch(url,{...options,headers:{'Content-Type':'application/json',...options.headers},signal:AbortSignal.timeout(10000)});const data=await response.json();if(!response.ok){if(response.status===401&&url!=='/api/session'){history.replaceState(null,'','#entrar');lockPlatform('Sua sessão expirou. Entre novamente para continuar.');}throw new Error(data.message||'Não foi possível concluir a solicitação.');}return data;}
function updateAuthView(){
 const activating=Boolean(inviteToken());
 const authenticated=authState.checked&&authState.authenticated&&!activating;
 const showingLogin=activating||(!authenticated&&location.hash==='#entrar');
 document.body.classList.toggle('auth-only',!authenticated);
 document.querySelector('#public-site').hidden=authenticated||showingLogin;
 document.querySelector('#login-screen').hidden=!showingLogin;
 document.querySelector('#sidebar').hidden=!authenticated;
 document.querySelector('.shell').hidden=!authenticated;
 document.querySelector('.skip-link').href=authenticated?'#main':showingLogin?'#login-content':'#apresentacao';
 const form=document.querySelector('#login-form'),status=document.querySelector('#session-status');
 form.hidden=activating||authenticated||!authState.available||!authState.accessConfigured;
 document.querySelector('#activate-form').hidden=!activating;
 document.querySelector('#login-title').textContent=activating?'Ative sua conta':'Entre na sua conta';
 document.querySelector('.login-description').textContent=activating?'Crie a senha que você usará para entrar na YENA.':'Acesse sua área na YENA com seu e-mail ou usuário.';
 status.textContent=authState.message||(!authState.checked?'Verificando acesso ao servidor…':!authState.available?'Não foi possível conectar ao servidor. Inicie a YENA com npm.cmd start.':!authState.accessConfigured?'O acesso administrativo precisa ser configurado no servidor.':'');
 status.hidden=activating||!status.textContent;
 document.querySelector('#session-retry').hidden=activating||authenticated||!['http:','https:'].includes(location.protocol)||(!status.textContent&&authState.available);
 document.querySelector('#open-local-app').hidden=authenticated||location.protocol!=='file:';
 if(!authenticated){document.title=showingLogin?'Acesso · YENA Healthcare Technology':'YENA Healthcare Technology';stopWebcam();closeMenu();main.replaceChildren();}
}
function lockPlatform(message=''){
 authVersion++;cancelChat();if(dialog.open)dialog.close();
 authState={...authState,checked:true,authenticated:false,message};
 dataConnection={...dataConnection,authenticated:false,user:null};
 clients=[];savedQuotes=[];quoteClientId='';messages=[{role:'assistant',text:demoGreeting}];reviewed=new Set();
 clientPortal=null;clientPortalError='';accounts=null;accountsError='';
 document.querySelector('#login-password').value='';document.querySelector('#login-password').type='password';document.querySelector('.password-toggle').setAttribute('aria-pressed','false');document.querySelector('.password-toggle').setAttribute('aria-label','Mostrar senha');
 updateAccount();updateAuthView();
}
async function refreshSession(hydrate=true){
 if(!['http:','https:'].includes(location.protocol)){authState={...authState,checked:true,available:false,message:'O login funciona pela aplicação com servidor. Execute npm.cmd start e abra o endereço local.'};updateAuthView();return false;}
 const version=authVersion;
 try{
  const session=await apiJSON('/api/session');if(version!==authVersion)return false;
  authState={checked:true,authenticated:session.authenticated===true,available:true,accessConfigured:session.accessConfigured===true,message:''};
  dataConnection={...dataConnection,authenticated:authState.authenticated,user:session.user,accessConfigured:authState.accessConfigured};
  if(!authState.authenticated){lockPlatform();return false;}
  updateAuthView();
  updateAccount();
  if(isClient()){
   if(hydrate)render();
   await loadCustomerPortal();
  }else if(hydrate){clients=seedClients();render();await Promise.all([discoverData(),discoverAI()]);if(route==='convites')await loadInvites();}
  return authState.authenticated;
 }catch{if(version===authVersion){authState.available=false;lockPlatform('Não foi possível conectar ao servidor. Verifique se a YENA está em execução.');}return false;}
}
function canSave(){return dataConnection.configured&&dataConnection.ready&&dataConnection.authenticated;}
function storageNotice(){
 if(!dataConnection.configured)return notice('<strong>Demonstração sem banco configurado.</strong> Os registros desta página ficam na memória e são perdidos ao recarregar. Para guardar clientes e orçamentos, use o servidor com MySQL configurado.');
 if(!dataConnection.ready)return notice('<strong>MySQL indisponível.</strong> Não foi possível acessar o banco. Verifique o servidor antes de cadastrar ou salvar registros.',true);
 if(!dataConnection.authenticated)return notice('<strong>Armazenamento MySQL disponível.</strong> Entre com o acesso administrativo para consultar e salvar seus registros. <button class="text-link" data-action="login">Entrar na plataforma</button>');
 return notice('<strong>Dados persistentes no MySQL.</strong> Clientes e orçamentos são gravados no servidor após confirmação. Use dados fictícios na apresentação acadêmica.');
}
function updateAccount(){const button=document.querySelector('#account-button');if(!button)return;button.hidden=!dataConnection.accessConfigured;button.textContent=dataConnection.authenticated?'Sair':'Entrar';button.dataset.action=dataConnection.authenticated?'logout':'login';}
async function discoverData(){
 if(!authState.authenticated)return;
 const version=authVersion;
 try{const status=await apiJSON('/api/data/status');if(version!==authVersion||status.storage!=='mysql')return;dataConnection=status;if(status.configured){clients=[];savedQuotes=[];if(canSave()){const [c,q]=await Promise.all([apiJSON('/api/clients'),apiJSON('/api/quotes')]);if(version!==authVersion)return;clients=c.clients;savedQuotes=q.quotes;}}updateAccount();if(['inicio','clientes','orcamentos','configuracoes'].includes(route)&&!dialog.open)render();}catch{if(version===authVersion&&dataConnection.configured){dataConnection.ready=false;clients=[];savedQuotes=[];if(['clientes','orcamentos'].includes(route)&&!dialog.open)render();}}
}
function loginDialog(){location.hash='entrar';}
async function loadCustomerPortal(){
 const version=authVersion;
 try{
  const result=await apiJSON('/api/me');
  if(version!==authVersion)return;
  const changed=clientPortalError||JSON.stringify(result)!==JSON.stringify(clientPortal);
  clientPortal=result;clientPortalError='';
  if(changed)render();
 }catch(error){if(version===authVersion){clientPortalError=error.message;render();}}
}
async function loadInvites(){
 const version=authVersion;
 try{
  const result=await apiJSON('/api/invites');
  if(version!==authVersion)return;
  accounts=result.accounts;accountsError='';
 }catch(error){if(version!==authVersion)return;accountsError=error.message;}
 if(route==='convites')render();
}
const roomName=id=>rooms.find(r=>r.id===id)?.name||'';
const priorityClass=value=>normalize(value);
function hospitalArt(){return `<svg viewBox="0 0 440 310" role="img" aria-label="Ilustração de uma plataforma de cuidado conectada"><defs><linearGradient id="art-floor" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#e4d8f4"/><stop offset="1" stop-color="#cbb5e6"/></linearGradient><linearGradient id="art-wall" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#fff"/><stop offset="1" stop-color="#e3d5f2"/></linearGradient></defs><ellipse cx="232" cy="250" rx="157" ry="28" fill="#e5d9f2"/><g fill="none" stroke="#ceb8e2" stroke-dasharray="4 6"><path d="M80 190L230 275l155-89M94 91l146-57 142 75M230 275v-47"/></g><path d="M96 169l132-76 145 84-132 77z" fill="url(#art-floor)"/><path d="M96 169v11l145 85v-11z" fill="#c0a4db"/><path d="M241 254v11l132-76v-12z" fill="#af8fd0"/><path d="M96 169V96l132-76v73z" fill="url(#art-wall)" transform="translate(0 38)"/><path d="M228 58l145 84v73l-145-84z" fill="#d5c0e9"/><path d="M234 68l129 75v56l-129-75z" fill="#e9def3"/><path d="M111 136l44-25v48l-44 25z" fill="#fff" stroke="#d6c1e8"/><path d="M116 139l34-20v25l-34 20z" fill="#c4afdd"/><path d="M116 146l34-20M132 130v25" stroke="#f4edf9" stroke-width="2"/><path d="M180 95l29-17v52l-29 17z" fill="#baa0d5"/><path d="M185 98l19-11v44l-19 11z" fill="#e5d7ef"/><path d="M199 114v6" stroke="#aa8bc4"/><path d="M153 198l55-32 62 36-55 32z" fill="#fff"/><path d="M153 198v17l62 36v-17z" fill="#d8c5e8"/><path d="M215 234v17l55-32v-17z" fill="#bc9dd6"/><path d="M162 192l29-17 53 30-29 17z" fill="#f7f1fc"/><path d="M231 146l30-18 52 30-30 18z" fill="#fff"/><path d="M231 146v34l52 30v-34z" fill="#c9b1e0"/><path d="M283 176v34l30-18v-34z" fill="#b697cf"/><path d="M250 157l14 8v14l-14-8z" fill="#f4e8ff"/><path d="M257 159v15M251 163l12 7" stroke="#9563bd" stroke-width="2.5"/><path d="M304 199l19-11 19 11-19 11z" fill="#c3acd6"/><path d="M310 189v-25" stroke="#ab8bc2" stroke-width="3"/><ellipse cx="310" cy="160" rx="15" ry="18" fill="#b9bbaf" transform="rotate(-25 310 160)"/><ellipse cx="320" cy="170" rx="10" ry="15" fill="#9fb7a9" transform="rotate(25 320 170)"/><path d="M307 186l18 10-4 17-11-6z" fill="#f2a66f"/><path d="M115 120l12 7v8l-12-7z" fill="#76499e"/><path d="M127 127l9-5v8l-9 5z" fill="#9469b7"/><path d="M113 124v-6" stroke="#aa8bc0" stroke-width="2"/><g transform="translate(334 79)"><circle r="29" fill="#faf7fd" stroke="#d4bde8"/><path d="M-16 0s6-10 16-10S16 0 16 0 10 10 0 10-16 0-16 0z" fill="none" stroke="#9766be" stroke-width="2"/><circle r="4" fill="#eda168"/></g><path d="M319 104l-20 32M135 108l30 7" stroke="#b494d0" stroke-width="1.5" stroke-dasharray="4 4"/><circle cx="188" cy="204" r="5" fill="#f5a36a"/><circle cx="188" cy="204" r="13" stroke="#eda168" fill="none" opacity=".5"/><circle cx="188" cy="204" r="23" stroke="#eda168" fill="none" opacity=".2"/><g fill="#bd9cd9"><circle cx="84" cy="225" r="3"/><circle cx="362" cy="231" r="3"/><circle cx="194" cy="44" r="3"/></g></svg>`;}
function home(){return `${heading('Bem-vindo à YENA','Um novo olhar para a tecnologia. Mais presença no cuidado.',`<a href="#orcamentos" class="button secondary">${icon('plus')} Criar orçamento</a>`)}
 <section class="hero" aria-labelledby="hero-title"><div class="hero-content"><div class="eyebrow">Inteligência que cuida</div><h2 id="hero-title">Cuidando quando<br><em>não se pode ver.</em></h2><p>Conectamos a ideia de um cuidado mais atento ao potencial da tecnologia. Conheça a YENA Healthcare Technology.</p><div class="hero-actions"><a class="button" href="#monitoramento">Explorar o painel ${icon('arrow')}</a><a class="button secondary" href="#ai">${icon('sparkle')} Conhecer a YENA AI</a></div></div><div class="hero-art">${hospitalArt()}<div class="art-label first">${icon('shield')}<span><strong>Um olhar mais atento</strong>Tecnologia e cuidado humano</span></div><div class="art-label second">${icon('heart')}<span><strong>O cuidado no centro</strong>Conheça nossa proposta</span></div></div></section>
 <div class="stats"><div class="stat"><div class="stat-icon">${icon('camera')}</div><div><div class="stat-value">04</div><div class="stat-label">Ambientes demonstrativos</div></div><span class="stat-side">Simulados</span></div><div class="stat"><div class="stat-icon">${icon('alert')}</div><div><div class="stat-value">03</div><div class="stat-label">Alertas de demonstração</div></div><span class="stat-side">Exemplos</span></div><div class="stat"><div class="stat-icon">${icon('users')}</div><div><div class="stat-value">${dataConnection.configured&&!dataConnection.authenticated?'—':String(clients.length).padStart(2,'0')}</div><div class="stat-label">Clientes cadastrados</div></div><span class="stat-side">Fictícios</span></div></div>
 <div class="home-grid"><section class="panel"><div class="panel-heading"><div><h2>Uma visão dos ambientes</h2><p>Explore a experiência de monitoramento simulado</p></div><a href="#monitoramento" class="text-link">Ver painel ${icon('arrow')}</a></div><div class="panel-body"><div class="room-mini-grid">${rooms.map(r=>`<div class="mini-room">${icon('camera')}<div><strong>${r.name}</strong><small>${r.code} · ${r.online?'Sinal simulado':'Indisponível na simulação'}</small></div><span class="status-dot${r.online?'':' offline'}" aria-hidden="true"></span></div>`).join('')}</div><p class="panel-note">${icon('info')} Não há câmeras físicas de rede conectadas. Todos os estados são fictícios.</p></div></section>
 <section class="panel"><div class="panel-heading"><div><h2>Alertas de exemplo</h2><p>Eventos fictícios para conhecer o painel</p></div><a href="#monitoramento" class="text-link">Ver todos ${icon('arrow')}</a></div><div class="panel-body">${alerts.map(a=>`<div class="alert-item"><div class="alert-indicator ${priorityClass(a.priority)}">${icon('alert')}</div><div><strong>${a.title}</strong><p>${roomName(a.room)} · Prioridade ${a.priority.toLowerCase()}</p></div><time>${a.time}</time></div>`).join('')}</div></section></div>
 <div class="section-heading"><div><h2>Tecnologia com propósito</h2><p>Conheça os pilares da nossa proposta de cuidado</p></div><span class="eyebrow" style="font-size:8px">YENA Healthcare</span></div>
 <section class="services" aria-label="Serviços e diferenciais"><article class="service">${icon('eye')}<h3>Monitoramento de ambientes</h3><p>Uma proposta de visão centralizada de ambientes, com organização de alertas por local e prioridade. Explore o painel simulado.</p></article><article class="service">${icon('sparkle')}<h3>Inteligência Artificial</h3><p>Uma proposta de apoio à organização de informações e à rotina comercial. Experimente o assistente local demonstrativo.</p></article><article class="service">${icon('cube')}<h3>Realidade Aumentada</h3><p>Uma visão futura de informações digitais no contexto do ambiente físico, para apoiar a compreensão de espaços.</p><span class="future">Conceito futuro · não implementado</span></article></section>
 <section class="purpose" aria-label="Missão, visão e valores"><div><h3><span>01</span> Nossa missão</h3><p>Propor tecnologias que apoiem o cuidado humano, tornando informações sobre ambientes mais acessíveis e organizadas.</p></div><div><h3><span>02</span> Nossa visão</h3><p>Inspirar um futuro em que inovação e atenção às pessoas caminhem juntas nos ambientes de cuidado.</p></div><div><h3><span>03</span> Nossos valores</h3><p>Empatia, acessibilidade, transparência e responsabilidade. A tecnologia como apoio às pessoas, com respeito à privacidade.</p></div></section>`;}
function roomArt(index){const fill=['#ddd4e9','#d8d4e6','#d6e1df','#ded9e4'][index];return `<svg viewBox="0 0 500 230" role="img" aria-label="Ilustração de ambiente fictício, sem imagens reais"><rect width="500" height="230" fill="#f0edf5"/><path d="M0 162L244 50l256 109v71H0z" fill="${fill}"/><path d="M0 0h500v159L244 50 0 162z" fill="#e8e1ef"/><path d="M244 0v50l256 109V0z" fill="#e1d7eb"/><g fill="none" stroke="#c9bbd5" opacity=".5"><path d="M0 192L272 63M45 230L327 86M172 230L388 111M304 230l143-93M0 165l150 65M90 120l248 110M163 88l315 142"/></g>${index===1?'<path d="M197 21v54l47-25 44 19V15" fill="#cab8db"/><path d="M208 19v48l36-19 33 14V17" fill="#e2d7ec"/><path d="M0 96l95-43v66L0 162zM324 24l55 23v62l-55-24z" fill="#c5b1d7"/><path d="M9 102l77-35v41L9 145zM333 39l37 15v42l-37-15z" fill="#eee8f5"/>':'<path d="M45 79l80-37v60l-80 37z" fill="#b9accf"/><path d="M53 84l64-29v40l-64 30z" fill="#ede7f5"/><path d="M85 70v40" stroke="#c4b5d6" stroke-width="3"/><path d="M270 64l74 32v51l-74-32z" fill="#baacd0"/><path d="M278 76l58 25v33l-58-25z" fill="#eee8f5"/>'}${index===2?'<path d="M125 150l48-22 88 38-48 23z" fill="#b6c9c3"/><path d="M125 150v25l88 38v-24z" fill="#a3bab3"/><path d="M213 189v24l48-23v-24z" fill="#96ada7"/><path d="M287 171l39-18 49 22-39 18z" fill="#faf7fc"/><path d="M287 171v13l49 22v-13z" fill="#c1b0d0"/><path d="M336 193v13l39-18v-13z" fill="#ae9abb"/>':'<path d="M128 144l63-28 110 47-64 30z" fill="#faf7fd"/><path d="M128 144v27l109 47v-25z" fill="#c7b4d8"/><path d="M237 193v25l64-30v-25z" fill="#af95c4"/><path d="M181 129l26-12 44 19-26 12z" fill="#926eaf"/><path d="M181 129v17l44 19v-17z" fill="#ab8bc4"/>'}<path d="M398 153v-30" stroke="#9db1a7" stroke-width="4"/><ellipse cx="393" cy="115" rx="15" ry="23" fill="#b2c5b9" transform="rotate(-20 393 115)"/><ellipse cx="409" cy="129" rx="11" ry="18" fill="#9eb5a8" transform="rotate(30 409 129)"/><path d="M383 150l29 12-5 22-17-7z" fill="#dbaa8d"/><path d="M222 24l13 6v9l-13-6z" fill="#9a7eb4"/><path d="M235 30l10-5v9l-10 5z" fill="#b39acb"/><circle cx="278" cy="177" r="5" fill="#e9a075"/><circle cx="278" cy="177" r="18" fill="none" stroke="#e9a075" opacity=".5"/></svg>`;}
function monitoring(){return `${heading('Monitoramento','Ambientes e alertas reunidos em uma visão demonstrativa.')} ${notice('<strong>Monitoramento simulado.</strong> As ilustrações, conexões, horários e alertas são fictícios. Não há câmeras físicas de rede conectadas nem análise de imagens reais.')}
 <div class="filters"><div class="field"><label for="room-filter">Ambiente</label><select id="room-filter"><option value="todos">Todos os ambientes</option>${rooms.map(r=>`<option value="${r.id}"${monitorFilters.room===r.id?' selected':''}>${r.name}</option>`).join('')}</select></div><div class="field"><label for="priority-filter">Prioridade dos alertas</label><select id="priority-filter">${['todas','Alta','Média','Baixa'].map(p=>`<option value="${p}"${monitorFilters.priority===p?' selected':''}>${p==='todas'?'Todas as prioridades':p}</option>`).join('')}</select></div><button class="button secondary" data-action="clear-monitor">Limpar filtros</button></div>
 <section aria-label="Câmeras demonstrativas" class="camera-grid" id="camera-grid">${cameraCards()}</section><div class="section-heading"><div><h2>Central de alertas</h2><p>Horários ilustrativos · alterações válidas apenas nesta sessão</p></div><span id="alert-count" class="muted" style="font-size:10px"></span></div><section class="panel" id="alerts-table" aria-label="Alertas simulados">${alertTable()}</section>`;}
function filteredAlerts(){return alerts.filter(a=>(monitorFilters.room==='todos'||a.room===monitorFilters.room)&&(monitorFilters.priority==='todas'||a.priority===monitorFilters.priority));}
function cameraCards(){return rooms.filter(r=>monitorFilters.room==='todos'||r.id===monitorFilters.room).map(r=>`<article class="camera-card"><div class="camera-visual">${roomArt(rooms.indexOf(r))}<span class="camera-overlay">ILUSTRAÇÃO · SIMULAÇÃO</span>${!r.online?`<div class="offline-message">${icon('offline')}Sinal indisponível na simulação</div>`:''}</div><div class="camera-bottom"><div><h3>${r.name}</h3><p>${r.code} · Ambiente fictício</p></div><span class="status${r.online?'':' offline'}"><span class="status-dot${r.online?'':' offline'}"></span>${r.online?'Conectada':'Desconectada'} (simulação)</span></div></article>`).join('');}
function alertTable(){const list=filteredAlerts();return list.length?`<div class="table-wrap"><table class="data-table"><thead><tr><th>Evento demonstrativo</th><th>Ambiente</th><th>Horário fictício</th><th>Prioridade</th><th>Revisão</th><th><span class="sr-only">Ações</span></th></tr></thead><tbody>${list.map(a=>`<tr><td><strong>${a.title}</strong><small>Evento simulado</small></td><td>${roomName(a.room)}</td><td>${a.time}</td><td><span class="priority ${priorityClass(a.priority)}">${a.priority}</span></td><td>${reviewed.has(a.id)?'<span class="reviewed">Revisado</span>':'Pendente'}</td><td><button class="text-link" data-action="alert-detail" data-id="${a.id}">Ver detalhes ${icon('chevron')}</button></td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">Nenhum alerta corresponde aos filtros selecionados.</div>';}
function updateMonitor(){document.querySelector('#camera-grid').innerHTML=cameraCards();document.querySelector('#alerts-table').innerHTML=alertTable();document.querySelector('#alert-count').textContent=`${filteredAlerts().length} alerta(s)`;}
function customers(){return `${heading('Clientes','Organize os contatos e as necessidades de cada instituição.',`<button class="button" data-action="client-new"${dataConnection.configured&&!canSave()?' disabled':''}>${icon('plus')} Novo cliente</button>`)}${storageNotice()}
 <div class="filters"><div class="field search-field"><label class="sr-only" for="client-search">Buscar cliente, instituição ou contato</label><div class="search-wrap">${icon('search')}<input class="search-input" id="client-search" type="search" placeholder="Buscar nome, instituição ou contato..." value="${esc(clientFilters.search)}" maxlength="120"></div></div><div class="field"><label class="sr-only" for="client-stage">Filtrar por etapa</label><select id="client-stage">${['todas','Novo contato','Em análise','Orçamento enviado'].map(s=>`<option${clientFilters.stage===s?' selected':''} value="${s}">${s==='todas'?'Todas as etapas':s}</option>`).join('')}</select></div></div><section class="panel" id="clients-table" aria-label="Lista de clientes">${clientTable()}</section>`;}
function filteredClients(){const t=normalize(clientFilters.search);return clients.filter(c=>(clientFilters.stage==='todas'||c.stage===clientFilters.stage)&&normalize(`${c.name} ${c.institution} ${c.contact}`).includes(t));}
function clientTable(){const list=filteredClients();return `${list.length?`<div class="table-wrap"><table class="data-table"><thead><tr><th>Cliente</th><th>Instituição</th><th>Etapa</th><th>Ações</th></tr></thead><tbody>${list.map(c=>`<tr><td><div class="client-name"><span class="client-avatar">${esc(c.name.split(' ').map(n=>n[0]).slice(0,2).join(''))}</span><div><strong>${esc(c.name)}</strong><small>${esc(c.contact)}</small></div></div></td><td>${esc(c.institution)}</td><td><span class="priority ${c.stage==='Novo contato'?'baixa':c.stage==='Orçamento enviado'?'':'baixa'}">${esc(c.stage)}</span></td><td><div class="actions"><button class="icon-button" data-action="client-view" data-id="${c.id}" aria-label="Visualizar ${esc(c.name)}">${icon('eye')}</button><button class="icon-button" data-action="client-edit" data-id="${c.id}" aria-label="Editar ${esc(c.name)}">${icon('edit')}</button><button class="icon-button" data-action="client-delete" data-id="${c.id}" aria-label="Excluir ${esc(c.name)}">${icon('trash')}</button></div></td></tr>`).join('')}</tbody></table></div>`:`<div class="empty">${dataConnection.configured&&!dataConnection.authenticated?'Entre para consultar os registros no MySQL.':'Nenhum cliente encontrado.<br>Altere os filtros ou cadastre um contato fictício.'}</div>`}<div class="result-count">${list.length} de ${clients.length} registro(s) · ${dataConnection.configured?'banco MySQL':'demonstração temporária na sessão'}</div>`;}
function quotes(){return `${heading('Orçamentos','Uma estimativa transparente para cada necessidade.')}${notice('<strong>Estimativas acadêmicas.</strong> Os valores de referência fazem parte do TCC e não são preços comerciais definitivos. Nenhum serviço será contratado.',true)}
 <div class="quote-grid"><form id="quote-form" class="panel form-panel"><h2>Monte sua estimativa</h2><p>Selecione o plano, os equipamentos e os serviços.</p><div class="form-section"><fieldset class="plans"><legend>01 · Escolha o plano mensal</legend>${Object.entries(PLANS).map(([id,p])=>`<label class="plan-option"><input type="radio" name="plan" value="${id}"${quoteInput.plan===id?' checked':''} required><span><strong>${p.name}</strong><b>${money(p.price)}</b><small>por mês</small></span></label>`).join('')}</fieldset></div><div class="form-section"><h3>02 · Equipamentos</h3><div class="fields-row"><div class="field"><label for="quote-cameras">Câmeras inteligentes</label><input id="quote-cameras" name="cameras" type="number" min="0" max="10000" step="1" required value="${quoteInput.cameras}"><small>${money(PRICES.camera)} por unidade</small></div><div class="field"><label for="quote-badges">Crachás inteligentes</label><input id="quote-badges" name="badges" type="number" min="0" max="10000" step="1" required value="${quoteInput.badges}"><small>${money(PRICES.badge)} por unidade</small></div></div></div><div class="form-section"><h3>03 · Serviços adicionais</h3><label class="option-row"><input type="checkbox" name="installation"${quoteInput.installation?' checked':''}><span><strong>Instalação</strong><small>Cobrança única no início</small></span><b>${money(PRICES.installation)}</b></label><label class="option-row"><input type="checkbox" name="maintenance"${quoteInput.maintenance?' checked':''}><span><strong>Manutenção</strong><small>Somada à mensalidade do plano</small></span><b>${money(PRICES.maintenance)}/mês</b></label></div><p class="panel-note">${icon('info')} A tabela informa apenas preços de referência, sem diferenças de recursos entre planos.</p></form><aside class="panel quote-summary" id="quote-summary" aria-label="Resumo do orçamento" aria-live="polite">${quoteSummary()}</aside></div>`;}
function quoteSummary(error=''){if(error)return `<div class="summary-head"><h2>Revise os campos</h2></div><div class="summary-body"><p class="error">${esc(error)}</p><p class="muted">Use quantidades inteiras de 0 a 10.000.</p></div>`;const q=calculateQuote(quoteInput);return `<div class="summary-head"><div class="eyebrow">Seu planejamento</div><h2>Resumo da estimativa</h2></div><div class="summary-body"><div class="cost-group"><h3>Investimento inicial · único</h3><div class="cost-line"><span>Câmeras (${q.cameras} × ${money(PRICES.camera)})</span><b>${money(q.cameraCost)}</b></div><div class="cost-line"><span>Crachás (${q.badges} × ${money(PRICES.badge)})</span><b>${money(q.badgeCost)}</b></div><div class="cost-line"><span>Instalação${q.installation?'':' (não incluída)'}</span><b>${money(q.installationCost)}</b></div><div class="cost-total"><span>Total inicial</span><b data-total="initial">${money(q.initial)}</b></div></div><div class="cost-group"><h3>Recorrência mensal</h3><div class="cost-line"><span>Plano ${PLANS[q.plan].name}</span><b>${money(q.planCost)}</b></div><div class="cost-line"><span>Manutenção${q.maintenance?'':' (não incluída)'}</span><b>${money(q.maintenanceCost)}</b></div><div class="cost-total monthly-total"><span>Total mensal</span><b data-total="monthly">${money(q.monthly)}<small>/mês</small></b></div></div><button type="button" class="button" data-action="quote-generate">${icon('document')} Gerar resumo ${icon('arrow')}</button></div><div class="summary-foot">Valores acadêmicos de referência. Equipamentos e instalação são cobrados uma vez; plano e manutenção compõem o custo mensal.</div>`;}
function updateQuote(){const form=document.querySelector('#quote-form'),fd=new FormData(form);const candidate={plan:fd.get('plan'),cameras:fd.get('cameras')===''?NaN:Number(fd.get('cameras')),badges:fd.get('badges')===''?NaN:Number(fd.get('badges')),installation:fd.has('installation'),maintenance:fd.has('maintenance')};try{calculateQuote(candidate);quoteInput=candidate;document.querySelector('#quote-summary').innerHTML=quoteSummary();return true;}catch(e){document.querySelector('#quote-summary').innerHTML=quoteSummary(e.message);return false;}}
function aiModeNotice(){return aiMode==='deepseek'?notice('<strong>Consultas ao DeepSeek pelo servidor.</strong> As mensagens enviadas neste modo seguem para o provedor. Cadastros não são enviados automaticamente; fichas e cálculos continuam locais. Não envie dados pessoais reais ou de saúde.'):notice('<strong>Assistente demonstrativo com regras locais.</strong> Nenhuma IA externa é consultada neste modo. Para usar o DeepSeek, execute o servidor com a credencial configurada.');}
function aiStateLabel(){return aiMode==='deepseek'?'DeepSeek · configurado para consulta':'Regras locais · demonstração';}
function ai(){return `${heading('YENA AI','Informações claras, estimativas e apoio à organização comercial.')}<div id="ai-mode-notice">${aiModeNotice()}</div><div class="ai-mode-panel"><div class="field"><label for="ai-mode">Modo de conversa</label><select id="ai-mode"><option value="demo"${aiMode==='demo'?' selected':''}>Demonstração · regras locais</option><option value="deepseek"${aiMode==='deepseek'?' selected':''}${aiConnection.configured?'':' disabled'}>DeepSeek · IA pelo servidor</option></select></div><p id="ai-connection-status">${esc(aiConnection.configured?'Credencial configurada no servidor. A primeira consulta verificará o acesso.':aiConnection.available?'Servidor disponível; chave do DeepSeek ainda não configurada.':'Modo local disponível. A integração DeepSeek requer o servidor da YENA.')}</p></div>
 <div class="chat-layout"><section class="panel chat-panel" aria-label="Conversa com o assistente"><div class="chat-header"><span class="ai-avatar">${icon('sparkle')}</span><div><strong>YENA AI</strong><small id="ai-state-label">${aiStateLabel()}</small></div><button class="icon-button" style="margin-left:auto" data-action="chat-clear" aria-label="Limpar conversa">${icon('reset')}</button></div><div class="chat-messages" id="chat-messages" role="log" aria-live="polite" aria-relevant="additions">${messages.map(messageMarkup).join('')}</div><p class="chat-pending" id="chat-pending" role="status"${chatBusy?'':' hidden'}>Consultando o DeepSeek…</p><form class="chat-input-area" id="chat-form"><label class="sr-only" for="chat-input">Sua mensagem para YENA AI</label><div class="chat-input-row"><textarea id="chat-input" name="message" rows="1" placeholder="Pergunte sobre a YENA ou calcule um orçamento..." maxlength="1500" required></textarea><button type="submit" class="button" aria-label="Enviar mensagem">${icon('send')}</button></div><small>Confira a origem indicada em cada resposta. Enter envia; Shift + Enter quebra a linha.</small></form></section>
 <aside class="panel chat-tools"><h3>Por onde começar?</h3><p>Explore as informações do projeto.</p><button class="prompt-button" data-prompt="O que é a YENA e quais são seus serviços?">Conhecer a YENA ${icon('arrow')}</button><button class="prompt-button" data-prompt="Quais são os preços dos planos e equipamentos?">Consultar os preços ${icon('arrow')}</button><button class="prompt-button" data-prompt="Calcule um orçamento Profissional com 4 câmeras, 20 crachás, com instalação e manutenção.">Calcular uma estimativa ${icon('arrow')}</button><button class="prompt-button" data-prompt="Prepare um resumo comercial da YENA.">Preparar resumo comercial ${icon('arrow')}</button><hr><h3>Ficha de potencial cliente</h3><p>Organize apenas as informações já cadastradas na sessão.</p><div class="field"><label for="ai-client">Selecionar cliente</label><select id="ai-client"${clients.length?'':' disabled'}>${clients.length?clients.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join(''):'<option>Nenhum cliente cadastrado</option>'}</select></div><button class="button soft" data-action="client-brief"${clients.length?'':' disabled'}>${icon('document')} Preparar ficha</button><a class="text-link" href="#clientes">Gerenciar clientes ${icon('arrow')}</a></aside></div>`;}
function messageMarkup(m){const source=m.source==='deepseek'?`DeepSeek · ${m.model||aiConnection.model}`:m.source==='error'?'Falha na consulta · sem resposta do modelo':m.source==='info'?'Informação do protótipo':'Regras locais · sem consulta externa';return `<div class="message ${m.role==='user'?'user':''}"><span class="ai-avatar" aria-label="${m.role==='user'?'Você':'YENA AI'}">${m.role==='user'?'V':icon('sparkle')}</span><div class="message-content"><div class="message-body">${esc(m.text)}</div>${m.role==='assistant'?`<small class="message-source">${esc(source)}</small>`:''}</div></div>`;}
function addMessage(role,text,meta={}){const m={role,text,...meta};messages.push(m);const log=document.querySelector('#chat-messages');if(log){log.insertAdjacentHTML('beforeend',messageMarkup(m));log.scrollTop=log.scrollHeight;}}
function updateChatBusy(){const form=document.querySelector('#chat-form');if(form)form.setAttribute('aria-busy',String(chatBusy));document.querySelectorAll('#chat-input,#chat-form button,#ai-mode,[data-prompt],[data-action="chat-clear"],[data-action="client-brief"]').forEach(el=>{el.disabled=chatBusy||(el.dataset.action==='client-brief'&&!clients.length);});const pending=document.querySelector('#chat-pending');if(pending)pending.hidden=!chatBusy;}
function cancelChat(){chatVersion++;chatController?.abort();chatController=null;chatBusy=false;updateChatBusy();}
function updateAIConnectionUI(){
 if(!authState.authenticated)return;
 if(messages.length===1){messages[0]={role:'assistant',source:'info',text:aiMode==='deepseek'?'Olá! Eu sou a YENA AI. O servidor está configurado para consultar o DeepSeek.\n\nAs mensagens enviadas no modo DeepSeek seguem para esse provedor. Fichas de clientes e cálculos de orçamento continuam locais, com a origem indicada em cada resposta. Posso apresentar a empresa, seus serviços propostos e preparar resumos comerciais.\n\nComo posso ajudar?':demoGreeting};}
 if(route==='ai'){const draft=document.querySelector('#chat-input')?.value||'';main.innerHTML=ai();document.querySelector('#chat-input').value=draft;updateChatBusy();}
}
async function discoverAI(){
 if(!authState.authenticated)return;
 try{const response=await fetch('/api/ai/status',{cache:'no-store',signal:AbortSignal.timeout(4000)});if(!response.ok)return;const data=await response.json();if(data.provider!=='deepseek'||typeof data.configured!=='boolean')return;aiConnection={configured:data.configured,model:String(data.model||''),available:true};aiMode=data.configured?'deepseek':'demo';updateAIConnectionUI();}catch{/* Uma página estática continua funcionando no modo local. */}
}
function aiAnswer(input){const t=normalize(input);
 if(/orcamento|estimativa|calcule|calcular/.test(t)){const result=parseQuote(input);return result.error||`${quoteText(result.quote)}\n\nCritérios de leitura: quantidades ausentes = 0; instalação e manutenção só são incluídas quando mencionadas sem negação. Confira os itens acima ou use o formulário de Orçamentos.`;}
 if(/resumo|comercial|apresentacao/.test(t))return 'RESUMO COMERCIAL · DEMONSTRAÇÃO\n\nYENA Healthcare Technology é uma empresa fictícia de um TCC, com o slogan “Cuidando quando não se pode ver”. Sua proposta reúne tecnologia e cuidado humano.\n\nO protótipo oferece monitoramento simulado por ambientes, organização de alertas, um assistente demonstrativo e gestão temporária de contatos e estimativas. Inteligência Artificial e Realidade Aumentada fazem parte da proposta; a RA é um conceito futuro, sem implementação neste protótipo.\n\nPlanos de referência: Básico R$ 1.500,00/mês; Profissional R$ 2.500,00/mês; Premium R$ 4.000,00/mês. Equipamentos, instalação e manutenção são calculados à parte. Valores acadêmicos, sem validade comercial.\n\nPróximo passo sugerido: levantar a necessidade da instituição e preparar uma estimativa no módulo Orçamentos.';
 if(/ficha|potencia[il]|lead|cliente/.test(t))return 'Para preparar uma ficha sem inventar informações, selecione um cliente no painel de apoio e clique em “Preparar ficha”. Você pode cadastrar ou editar contatos fictícios em Clientes. Usarei apenas os campos existentes na sessão.';
 if(/prec|valor|custa|planos|mensal|tabela/.test(t))return `TABELA DE REFERÊNCIA ACADÊMICA\n\n${Object.values(PLANS).map(p=>`Plano ${p.name}: ${money(p.price)}/mês`).join('\n')}\nInstalação: ${money(PRICES.installation)} (única)\nCâmera inteligente: ${money(PRICES.camera)}/unidade\nCrachá inteligente: ${money(PRICES.badge)}/unidade\nManutenção: ${money(PRICES.maintenance)}/mês\n\nCustos iniciais = câmeras + crachás + instalação opcional.\nCustos mensais = plano + manutenção opcional.\n\nOs planos não têm diferenças de funcionalidades especificadas no projeto. Estes valores não são preços comerciais definitivos.`;
 if(/realidade|aumentada|\bra\b/.test(t))return 'A Realidade Aumentada faz parte da visão futura da YENA: apresentar informações digitais no contexto do ambiente físico. Não há recursos de RA, dispositivos reais ou integração com câmeras neste protótipo. Detalhes de implementação ainda não foram definidos.';
 if(/ia|inteligencia|modelo|externa|voce|funciona/.test(t)&&!/empresa|servico/.test(t))return 'Esta YENA AI é uma demonstração com regras locais e respostas pré-definidas, sem consulta a modelos externos. Posso calcular estimativas com a tabela do projeto e organizar informações de clientes cadastrados. Não faço detecção de eventos, análise de imagens, diagnóstico ou atendimento clínico.';
 if(/yena|empresa|servico|missao|visao|valores|diferencia/.test(t))return 'A YENA Healthcare Technology é uma empresa fictícia desenvolvida para um TCC.\n\nSlogan: “Cuidando quando não se pode ver”.\n\nMissão proposta: apoiar o cuidado humano com informações acessíveis e organizadas. Visão: aproximar inovação e atenção às pessoas. Valores: empatia, acessibilidade, transparência, responsabilidade e respeito à privacidade.\n\nA proposta explora monitoramento de ambientes, apoio com Inteligência Artificial e o conceito futuro de Realidade Aumentada. Neste protótipo, o monitoramento é inteiramente simulado, o assistente funciona por regras locais e a RA não está implementada.\n\nOs diferenciais demonstrados são a centralização das informações, a organização de alertas por ambiente e prioridade e a separação clara dos custos nas estimativas.';
 if(/^(oi|ola|bom dia|boa tarde|boa noite|obrigad)/.test(t))return 'Olá! Posso ajudar com informações sobre a YENA, preços acadêmicos, estimativas e fichas de clientes. Para calcular, experimente: “Orçamento Básico com 2 câmeras, 10 crachás, sem instalação e com manutenção”.';
 return 'Não tenho essa informação na base deste projeto. Para evitar inventar dados, posso responder sobre a empresa, os serviços propostos, a tabela de preços acadêmicos, orçamentos e fichas de clientes cadastrados. Use uma das sugestões ao lado ou o formulário de Orçamentos.';
}
async function sendChat(input){
 const text=input.trim();if(!text||chatBusy)return;if(text.length>1500){toast('Use até 1.500 caracteres por mensagem.');return;}
 const local=aiMode!=='deepseek'||/orcamento|estimativa|calcule|calcular|ficha|potencia[il]|lead|cliente/.test(normalize(text));
 if(local){addMessage('user',text,{source:'local'});addMessage('assistant',aiAnswer(text),{source:'local'});return;}
 addMessage('user',text,{source:'deepseek'});chatBusy=true;chatController=new AbortController();const controller=chatController,version=chatVersion;updateChatBusy();
 try{
   let history=messages.filter(m=>m.source==='deepseek').slice(-10).map(m=>({role:m.role,content:m.text}));
   while(history.reduce((n,m)=>n+m.content.length,0)>16000&&history.length>1)history.shift();
   const timeout=setTimeout(()=>controller.abort('timeout'),40000);
   let response,data;
   try{response=await fetch('/api/ai/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:history}),signal:controller.signal});data=await response.json();}finally{clearTimeout(timeout);}
   if(response.status===401){lockPlatform('Sua sessão expirou. Entre novamente para continuar.');return;}
   if(!response.ok)throw new Error(typeof data.message==='string'?data.message:'Não foi possível consultar o DeepSeek.');
   if(data.provider!=='deepseek'||typeof data.text!=='string'||!data.text.trim())throw new Error('O servidor retornou uma resposta inválida.');
   if(version===chatVersion)addMessage('assistant',data.text+(data.truncated?'\n\nA resposta atingiu o limite de tamanho. Peça para continuar, se necessário.':''),{source:'deepseek',model:data.model});
 }catch(error){if(version===chatVersion)addMessage('assistant',controller.signal.aborted?'A consulta foi interrompida ou demorou mais que o esperado. Nenhuma resposta de IA foi recebida.':error instanceof TypeError?'Não foi possível acessar o servidor da YENA. Verifique se ele está em execução.':error.message,{source:'error'});}
 finally{if(version===chatVersion){chatBusy=false;chatController=null;updateChatBusy();}}
}
function settings(){return `${heading('Configurações','Acesso, armazenamento e preferências da plataforma.')}<div class="settings-grid">
 <section class="panel settings-card"><h2>Sobre a YENA</h2><p>Empresa fictícia desenvolvida para um Trabalho de Conclusão de Curso. Cuidando quando não se pode ver.</p><div class="detail-list"><div><span>Versão</span><strong>1.2 · protótipo acadêmico</strong></div><div><span>Interface</span><strong>Português brasileiro</strong></div><div><span>Monitoramento</span><strong>100% simulado</strong></div><div><span>Assistente</span><strong>${aiConnection.configured?'DeepSeek e modo local':'Modo local; DeepSeek não configurado'}</strong></div><div><span>Dispositivos físicos e RA</span><strong>Não integrados</strong></div></div></section>
 <section class="panel settings-card"><h2>Armazenamento e acesso</h2>${storageNotice()}<p>Clientes e orçamentos são persistidos quando o MySQL está disponível e o acesso está autenticado. Conversa, filtros e alertas de exemplo continuam temporários.</p><p style="margin-top:12px">No modo DeepSeek, as mensagens enviadas seguem para o provedor; os cadastros não são enviados automaticamente.</p>${dataConnection.accessConfigured?`<button class="button secondary" data-action="${dataConnection.authenticated?'logout':'login'}">${dataConnection.authenticated?'Encerrar sessão':'Entrar na plataforma'}</button>`:''}</section>
 <section class="panel settings-card"><h2>Acessibilidade</h2><label class="switch-label" for="reduced-motion"><span>Reduzir movimentos da interface</span><input id="reduced-motion" type="checkbox"${reducedMotion?' checked':''}></label><p>A preferência de movimento reduzido do sistema também é respeitada.</p><button class="button secondary" data-action="reset-demo">${icon('reset')} Restaurar exemplos da interface</button></section>
 <section class="panel settings-card"><h2>Identidade visual</h2><p>Identidade adaptada da referência fornecida para o projeto.</p><div class="brand-swatches"><span style="--swatch:#30155C">Roxo<small>#30155C</small></span><span style="--swatch:#DE5302">Laranja<small>#DE5302</small></span><span style="--swatch:#FFFFFF">Branco<small>#FFFFFF</small></span></div><p>Mais que tecnologia, é sobre pessoas.</p></section></div>`;}
function quoteHistory(){return `<div class="section-heading"><div><h2>Orçamentos salvos</h2><p>Histórico de estimativas acadêmicas no MySQL</p></div></div>${storageNotice()}<div class="panel">${savedQuotes.length?`<div class="table-wrap"><table class="data-table"><thead><tr><th>Plano / cliente</th><th>Inicial</th><th>Mensal</th><th>Data</th><th>Status</th><th>Ações</th></tr></thead><tbody>${savedQuotes.map(q=>`<tr><td><strong>${esc(PLANS[q.snapshot.plan]?.name||q.snapshot.plan)}</strong><small>${esc(q.clientName||'Sem vínculo com cliente')}</small></td><td>${money(q.snapshot.initial)}</td><td>${money(q.snapshot.monthly)}</td><td>${new Date(q.createdAt).toLocaleDateString('pt-BR')}</td><td><button class="button secondary" data-action="quote-status" data-id="${q.id}">${esc(q.snapshot.status||'Em análise')}</button></td><td><div class="actions"><button class="icon-button" data-action="quote-view" data-id="${q.id}" aria-label="Ver orçamento">${icon('eye')}</button><button class="icon-button" data-action="quote-delete" data-id="${q.id}" aria-label="Excluir orçamento">${icon('trash')}</button></div></td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">Nenhum orçamento salvo para exibir.</div>'}</div>`;}
function render(){
 updateAuthView();
 if(!authState.authenticated||inviteToken())return;
 stopWebcam();
 const availableRoutes=isClient()?clientRoutes:routes;
 document.querySelector('.sidebar .brand').href='#'+availableRoutes[0][0];
 renderNav(availableRoutes);
 let next=location.hash.slice(1);
 if(!availableRoutes.some(([id])=>id===next)){next=availableRoutes[0][0];history.replaceState(null,'','#'+next);}
 route=next;
 const [,label]=availableRoutes.find(([id])=>id===route);
 document.title=`${label} · YENA Healthcare Technology`;
 document.querySelector('#crumb').textContent=label;
 document.querySelector('.nav-label').textContent=isClient()?'ÁREA DO CLIENTE':'ADMINISTRAÇÃO';
 const link=document.querySelector(`[data-route="${route}"]`);
 link.classList.add('active');link.setAttribute('aria-current','page');
 const pages={inicio:home,monitoramento:()=>receptionPanel()+webcamPanel()+monitoring(),clientes:customers,orcamentos:()=>quotes()+'<section id="quote-history">'+quoteHistory()+'</section>',ai,configuracoes:settings,convites:()=>invitesPage(clients,accounts,accountsError)};
 main.innerHTML=isClient()?customerPage(route,clientPortal,clientPortalError):pages[route]();
 closeMenu();
 if(route==='monitoramento')updateMonitor();
 if(route==='ai')updateChatBusy();
 window.scrollTo({top:0,behavior:'instant'});
}
function closeMenu(){document.querySelector('#sidebar').classList.remove('open');document.querySelector('#scrim').hidden=true;document.querySelector('#menu-toggle').setAttribute('aria-expanded','false');}
function openDialog(title,body,actions='',formId=''){document.querySelector('#dialog-content').innerHTML=`${formId?`<form id="${formId}">`:''}<div class="dialog-header"><h2 id="dialog-title">${title}</h2><button type="button" class="icon-button" data-action="dialog-close" aria-label="Fechar janela">${icon('close')}</button></div><div class="dialog-body">${body}</div>${actions?`<div class="dialog-actions">${actions}</div>`:''}${formId?'</form>':''}`;if(!dialog.open)dialog.showModal();}
const closeButton='<button type="button" class="button secondary" data-action="dialog-close">Fechar</button>';
function clientForm(id){const c=clients.find(c=>c.id===id)||{name:'',institution:'',contact:'',need:'',stage:'Novo contato'};openDialog(id?'Editar cliente':'Novo cliente',`<p style="margin-bottom:17px">Use dados fictícios. ${dataConnection.configured?'O registro será salvo no MySQL após confirmação.':'O registro vale apenas para esta sessão de demonstração.'}</p><input type="hidden" name="id" value="${esc(id||'')}"><div class="field"><label for="client-name">Nome do contato *</label><input id="client-name" name="name" required maxlength="80" value="${esc(c.name)}" placeholder="Ex.: Ana Exemplo" autocomplete="off"></div><div class="field"><label for="client-institution">Instituição *</label><input id="client-institution" name="institution" required maxlength="120" value="${esc(c.institution)}" placeholder="Ex.: Clínica Modelo (fictícia)" autocomplete="off"></div><div class="field"><label for="client-contact">Contato profissional fictício *</label><input id="client-contact" name="contact" required maxlength="120" value="${esc(c.contact)}" placeholder="Ex.: ana@exemplo.invalid" autocomplete="off"><small>Um e-mail ou telefone de exemplo é suficiente.</small></div><div class="field"><label for="client-need">Necessidade *</label><textarea id="client-need" name="need" required maxlength="1000" placeholder="Descreva a necessidade da instituição, sem dados de saúde.">${esc(c.need)}</textarea></div><div class="field"><label for="client-status">Etapa</label><select id="client-status" name="stage">${['Novo contato','Em análise','Orçamento enviado'].map(s=>`<option${s===c.stage?' selected':''}>${s}</option>`).join('')}</select></div><p id="client-error" class="error" role="alert" hidden></p>`,`<button type="button" class="button secondary" data-action="dialog-close">Cancelar</button><button type="submit" class="button">${icon('check')} ${dataConnection.configured?'Salvar no MySQL':'Salvar na sessão'}</button>`,'client-form');}
function alertDetail(id){const a=alerts.find(a=>a.id===id);if(!a)return;openDialog('Detalhes do alerta',`<span class="priority ${priorityClass(a.priority)}">Prioridade ${a.priority.toLowerCase()}</span><h3 style="margin:17px 0 10px">${a.title}</h3><p>${a.description}</p><dl><dt>Ambiente</dt><dd>${roomName(a.room)}</dd><dt>Horário fictício</dt><dd>${a.time} · evento de demonstração</dd><dt>Contexto</dt><dd>${a.context}</dd><dt>Estado da revisão</dt><dd>${reviewed.has(id)?'Revisado nesta sessão':'Pendente de revisão'}</dd></dl>`,`${closeButton}${reviewed.has(id)?'':`<button class="button" data-action="alert-review" data-id="${id}">${icon('check')} Marcar como revisado</button>`}`);}
function download(filename,content){const blob=new Blob([content],{type:'text/plain;charset=utf-8'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Resumo preparado para download.');}
document.addEventListener('click',async event=>{
 const target=event.target.closest('[data-action],[data-prompt]');if(!target)return;
 if(target.dataset.prompt){if(authState.authenticated)sendChat(target.dataset.prompt);return;}
 const {action,id}=target.dataset;const c=id?clients.find(c=>c.id===id):null;
 if(action==='toggle-password'){const input=document.querySelector('#login-password'),show=input.type==='password';input.type=show?'text':'password';target.setAttribute('aria-pressed',String(show));target.setAttribute('aria-label',show?'Ocultar senha':'Mostrar senha');return;}
 if(action==='session-retry'){target.disabled=true;await refreshSession();target.disabled=false;return;}
 if(action==='login'){loginDialog();return;}
 if(!authState.authenticated)return;
 if(action==='logout'){target.disabled=true;try{await apiJSON('/api/session',{method:'DELETE'});history.replaceState(null,'','#entrar');lockPlatform('Sessão encerrada.');document.querySelector('#login-user').focus();}catch{toast('Não foi possível encerrar a sessão. Tente novamente.');}finally{target.disabled=false;}return;}
 if(action==='webcam-start'){await startWebcam(target);return;}
 if(action==='webcam-stop'){stopWebcam();return;}
 if(action==='simulate-motion'){simulateMotion(target);return;}
 if(action==='client-portal-retry'){await loadCustomerPortal();return;}
 if(isClient())return;
 if(action==='invites-retry'){await discoverData();await loadInvites();return;}
 if(action==='invite-create'&&c){
  const account=accounts?.find(item=>item.clientId===id);
  openDialog('Gerar convite',`<input type="hidden" name="clientId" value="${esc(id)}"><label class="field">E-mail de ${esc(c.name)} <input name="email" type="email" required maxlength="120" value="${esc(account?.email||c.contact)}"></label><p class="error" role="alert" hidden></p>`,`${closeButton}<button type="submit" class="button">Gerar link</button>`,'invite-form');
  return;
 }
 if(action==='invite-webcam'){
  target.disabled=true;
  try{await apiJSON('/api/invites',{method:'PUT',body:JSON.stringify({clientId:id,webcamEnabled:target.getAttribute('aria-pressed')==='false'})});await loadInvites();}
  catch(error){toast(error.message);}finally{target.disabled=false;}
  return;
 }
 if(action==='invite-copy'){
  const input=document.querySelector('#invite-link');
  input.select();
  try{await navigator.clipboard.writeText(input.value);toast('Link copiado.');}catch{toast('O link está selecionado. Pressione Ctrl+C para copiá-lo.');}
  return;
 }
 if(action==='quote-status'){
  const quote=savedQuotes.find(item=>item.id===id);
  if(!quote)return;
  openDialog('Atualizar status',`<input type="hidden" name="id" value="${esc(id)}"><label class="field">Status <select name="status">${quoteStatuses.map(status=>`<option${status===(quote.snapshot.status||'Em análise')?' selected':''}>${status}</option>`).join('')}</select></label><p class="error" role="alert" hidden></p>`,`${closeButton}<button type="submit" class="button">Salvar status</button>`,'quote-status-form');
  return;
 }
 if(action==='dialog-close'){dialog.close();return;}
 if(action==='clear-monitor'){monitorFilters={room:'todos',priority:'todas'};render();}
 if(action==='alert-detail')alertDetail(id);
 if(action==='alert-review'){reviewed.add(id);dialog.close();updateMonitor();toast('A revisão foi registrada nesta sessão.');}
 if(action==='client-new')clientForm();
 if(action==='client-edit'&&c)clientForm(id);
 if(action==='client-view'&&c)openDialog('Ficha do cliente',`<dl><dt>Nome</dt><dd>${esc(c.name)}</dd><dt>Instituição</dt><dd>${esc(c.institution)}</dd><dt>Contato</dt><dd>${esc(c.contact)}</dd><dt>Necessidade</dt><dd>${esc(c.need)}</dd><dt>Etapa</dt><dd>${esc(c.stage)}</dd></dl><p class="panel-note">${dataConnection.configured?'Registro persistente no MySQL':'Registro temporário na demonstração'}</p>`,`${closeButton}<button class="button" data-action="client-edit" data-id="${id}">${icon('edit')} Editar</button>`);
 if(action==='client-delete'&&c)openDialog('Excluir registro?',`<p>O registro de <strong>${esc(c.name)}</strong>, da instituição ${esc(c.institution)}, será removido ${dataConnection.configured?'do MySQL':'da sessão atual'}.</p>`,`<button class="button secondary" data-action="dialog-close">Cancelar</button><button class="button danger" data-action="client-confirm-delete" data-id="${id}">Excluir registro</button>`);
 if(action==='client-confirm-delete'&&c){target.disabled=true;try{if(dataConnection.configured)await apiJSON('/api/clients/'+id,{method:'DELETE'});clients=clients.filter(x=>x.id!==id);savedQuotes=savedQuotes.map(q=>q.clientId===id?{...q,clientId:null,clientName:null}:q);dialog.close();document.querySelector('#clients-table').innerHTML=clientTable();toast(dataConnection.configured?'Cliente excluído do MySQL.':'Registro excluído da sessão.');}catch(error){toast(error.message);target.disabled=false;}}
 if(action==='quote-generate'){if(!updateQuote())return;const q=calculateQuote(quoteInput);const association=canSave()?`<div class="field"><label for="summary-client">Vincular a um cliente (opcional)</label><select id="summary-client"><option value="">Sem vínculo</option>${clients.map(c=>`<option value="${c.id}">${esc(c.name)} · ${esc(c.institution)}</option>`).join('')}</select></div>`:storageNotice();openDialog('Resumo do orçamento',`<pre>${esc(quoteText(q))}</pre>${association}`,`${closeButton}<button class="button secondary" data-action="quote-download">${icon('download')} Baixar .txt</button>${canSave()?'<button class="button" data-action="quote-save">Salvar no MySQL</button>':''}`);}
 if(action==='quote-save'){if(!canSave())return;target.disabled=true;try{const {quote}=await apiJSON('/api/quotes',{method:'POST',body:JSON.stringify({...quoteInput,clientId:document.querySelector('#summary-client')?.value||null})});savedQuotes.unshift({...quote,clientName:clients.find(c=>c.id===quote.clientId)?.name||null,createdAt:new Date().toISOString()});document.querySelector('#quote-history').innerHTML=quoteHistory();target.textContent='Salvo no MySQL';toast('Orçamento salvo no MySQL.');}catch(error){target.disabled=false;toast(error.message);}}
 if(action==='quote-view'){const q=savedQuotes.find(q=>q.id===id);if(q)openDialog('Orçamento salvo no MySQL',`<pre>${esc(quoteText(q.snapshot))}</pre>`,closeButton);}
 if(action==='quote-delete')openDialog('Excluir orçamento?',`<p>O orçamento selecionado será removido do MySQL.</p>`,`<button class="button secondary" data-action="dialog-close">Cancelar</button><button class="button danger" data-action="quote-confirm-delete" data-id="${id}">Excluir orçamento</button>`);
 if(action==='quote-confirm-delete'){target.disabled=true;try{await apiJSON('/api/quotes/'+id,{method:'DELETE'});savedQuotes=savedQuotes.filter(q=>q.id!==id);dialog.close();document.querySelector('#quote-history').innerHTML=quoteHistory();toast('Orçamento excluído do MySQL.');}catch(error){target.disabled=false;toast(error.message);}}
 if(action==='quote-download'){try{download('YENA-estimativa-academica.txt',quoteText(calculateQuote(quoteInput)));}catch(e){toast(e.message);}}
 if(action==='chat-clear'){openDialog('Limpar conversa?',`<p>As mensagens serão removidas da sessão. A mensagem de apresentação será mantida.</p>`,`<button class="button secondary" data-action="dialog-close">Cancelar</button><button class="button" data-action="chat-confirm-clear">Limpar conversa</button>`);}
 if(action==='chat-confirm-clear'){cancelChat();messages=messages.slice(0,1);dialog.close();render();toast('Conversa limpa.');}
 if(action==='client-brief'){const selected=clients.find(c=>c.id===document.querySelector('#ai-client').value);if(!selected)return;addMessage('user',`Prepare a ficha de ${selected.name}.`);addMessage('assistant',`FICHA DE POTENCIAL CLIENTE · DEMONSTRAÇÃO\n\nNome: ${selected.name}\nInstituição: ${selected.institution}\nContato: ${selected.contact}\nNecessidade informada: ${selected.need}\nEtapa registrada: ${selected.stage}\n\nPlano de interesse: não definido em um campo específico.\nOrçamento disponível: não informado.\n\nPróximo passo sugerido: confirmar os requisitos com a instituição e montar uma estimativa acadêmica.\n\nFicha organizada apenas com os campos do cadastro atual. Nenhuma informação externa foi consultada.`);}
 if(action==='reset-demo')openDialog('Restaurar demonstração?',`<p>As preferências, a conversa e as revisões voltarão aos exemplos iniciais. ${dataConnection.configured?'Clientes e orçamentos do MySQL serão preservados.':'Os clientes temporários também voltarão aos exemplos.'}</p>`,`<button class="button secondary" data-action="dialog-close">Cancelar</button><button class="button" data-action="confirm-reset">Restaurar exemplos</button>`);
 if(action==='confirm-reset'){cancelChat();if(!dataConnection.configured)clients=seedClients();reviewed=new Set();messages=messages.slice(0,1);monitorFilters={room:'todos',priority:'todas'};clientFilters={search:'',stage:'todas'};quoteInput={plan:'profissional',cameras:4,badges:20,installation:true,maintenance:true};reducedMotion=false;document.body.classList.remove('no-motion');dialog.close();render();toast('Exemplos e preferências restaurados.');}
});
document.addEventListener('input',event=>{
 if(event.target.closest('#quote-form'))updateQuote();
 if(event.target.id==='client-search'){clientFilters.search=event.target.value;document.querySelector('#clients-table').innerHTML=clientTable();}
});
document.addEventListener('change',event=>{
 if(event.target.id==='ai-mode'){cancelChat();aiMode=event.target.value==='deepseek'&&aiConnection.configured?'deepseek':'demo';messages=[messages[0]];updateAIConnectionUI();toast(aiMode==='deepseek'?'Modo DeepSeek selecionado. As próximas mensagens serão enviadas ao provedor.':'Modo demonstração selecionado. Respostas por regras locais.');}
 if(event.target.id==='room-filter'){monitorFilters.room=event.target.value;updateMonitor();}
 if(event.target.id==='priority-filter'){monitorFilters.priority=event.target.value;updateMonitor();}
 if(event.target.id==='client-stage'){clientFilters.stage=event.target.value;document.querySelector('#clients-table').innerHTML=clientTable();}
 if(event.target.id==='reduced-motion'){reducedMotion=event.target.checked;document.body.classList.toggle('no-motion',reducedMotion);toast('Preferência atualizada para esta sessão.');}
});
document.addEventListener('submit',async event=>{
 const submitted=event.target;
 if(submitted.id==='public-quote-form')return;
 if(submitted.id==='activate-form'){
  event.preventDefault();
  const button=submitted.querySelector('[type="submit"]'),status=document.querySelector('#activate-status');
  const {password,confirmation}=submitted.elements;
  status.hidden=false;
  if(password.value!==confirmation.value){status.textContent='As senhas precisam ser iguais.';return;}
  button.disabled=true;
  status.textContent='Ativando conta…';
  try{
   await apiJSON('/api/activate',{method:'POST',body:JSON.stringify({token:inviteToken(),password:password.value})});
   submitted.reset();status.hidden=true;
   history.replaceState(null,'','#entrar');
   if(authState.authenticated){render();toast('Conta ativada. O cliente já pode entrar com o e-mail e a nova senha.');}
   else{lockPlatform('Conta ativada. Agora entre com seu e-mail e senha.');document.querySelector('#login-user').focus();}
  }catch(error){status.textContent=error.message;}
  finally{button.disabled=false;}
  return;
 }
 if(authState.authenticated&&!isClient()&&['invite-form','quote-status-form'].includes(submitted.id)){
  event.preventDefault();
  const fields=Object.fromEntries(new FormData(submitted));
  const button=submitted.querySelector('[type="submit"]'),status=submitted.querySelector('[role="alert"]');
  button.disabled=true;
  try{
   if(submitted.id==='invite-form'){
    const {url}=await apiJSON('/api/invites',{method:'POST',body:JSON.stringify(fields)});
    openDialog('Convite pronto',`<p>Envie o link ao cliente para que ele crie sua senha. Para testar neste computador, abra o link em uma janela anônima.</p><label class="field">Link do convite <input id="invite-link" readonly value="${esc(url)}"></label>`,`${closeButton}<button type="button" class="button" data-action="invite-copy">Copiar link</button>`);
    await loadInvites();
   }else{
    await apiJSON('/api/quotes/'+fields.id+'/status',{method:'PUT',body:JSON.stringify({status:fields.status})});
    const quote=savedQuotes.find(item=>item.id===fields.id);
    if(quote)quote.snapshot.status=fields.status;
    dialog.close();
    document.querySelector('#quote-history').innerHTML=quoteHistory();
    toast('Status atualizado.');
   }
  }catch(error){status.hidden=false;status.textContent=error.message;}
  finally{button.disabled=false;}
  return;
 }
 if(event.target.getAttribute('id')==='login-form'){event.preventDefault();const form=event.target,button=form.querySelector('[type="submit"]');if(button.disabled)return;button.disabled=true;button.textContent='Entrando…';const payload={username:form.elements.username.value.trim(),password:form.elements.password.value};form.elements.password.value='';document.querySelector('#login-error').hidden=true;try{await apiJSON('/api/session',{method:'POST',body:JSON.stringify(payload)});payload.password='';if(!await refreshSession())throw new Error('Não foi possível manter sua sessão. Verifique se os cookies estão habilitados.');render();main.focus({preventScroll:true});toast('Acesso autenticado.');}catch(error){payload.password='';const el=document.querySelector('#login-error');el.textContent=error.message;el.hidden=false;document.querySelector('#login-password').focus();}finally{button.disabled=false;button.textContent='Entrar';}return;}
 if(!authState.authenticated){event.preventDefault();return;}
 if(event.target.getAttribute('id')==='quote-form'){event.preventDefault();return;}
 if(event.target.getAttribute('id')==='client-form'){event.preventDefault();const form=event.target,button=form.querySelector('[type="submit"]');if(button.disabled)return;button.disabled=true;const fd=new FormData(form);try{let data=validateClient(Object.fromEntries(fd));if(dataConnection.configured){const response=await apiJSON('/api/clients'+(data.id?'/'+data.id:''),{method:data.id?'PUT':'POST',body:JSON.stringify(data)});data=response.client;}if(data.id&&clients.some(c=>c.id===data.id)){clients[clients.findIndex(c=>c.id===data.id)]=data;}else{data.id=data.id||crypto.randomUUID();clients.push(data);}dialog.close();document.querySelector('#clients-table').innerHTML=clientTable();toast(dataConnection.configured?'Cliente salvo no MySQL.':'Cliente salvo apenas nesta sessão.');}catch(e){const error=document.querySelector('#client-error');if(error){error.hidden=false;error.textContent=e.message;}button.disabled=false;}}
 if(event.target.getAttribute('id')==='chat-form'){event.preventDefault();const input=document.querySelector('#chat-input');sendChat(input.value);input.value='';input.focus();}
});
document.addEventListener('keydown',event=>{if(event.key==='Escape')closeMenu();if(event.target.id==='chat-input'&&event.key==='Enter'&&!event.shiftKey){event.preventDefault();document.querySelector('#chat-form').requestSubmit();}});
document.querySelector('#menu-toggle').addEventListener('click',()=>{const open=document.querySelector('#sidebar').classList.toggle('open');document.querySelector('#scrim').hidden=!open;document.querySelector('#menu-toggle').setAttribute('aria-expanded',String(open));if(open)document.querySelector('.nav-link.active')?.focus();});
document.querySelector('#scrim').addEventListener('click',closeMenu);
window.addEventListener('hashchange',()=>{
 if(dialog.open)dialog.close();
 render();
 if(inviteToken()){document.querySelector('#activate-password').focus();return;}
 if(!authState.authenticated){
  if(location.hash==='#entrar'){window.scrollTo(0,0);document.querySelector('#login-user').focus();}
  else document.getElementById(location.hash.slice(1)||'apresentacao')?.scrollIntoView();
  return;
 }
 if(route==='convites'){if(!accounts)discoverData().then(loadInvites);else loadInvites();}
 main.focus({preventScroll:true});
});
window.addEventListener('focus',()=>{if(authState.authenticated)refreshSession(false);});
window.addEventListener('pageshow',event=>{if(event.persisted)refreshSession();});
window.addEventListener('pagehide',stopWebcam);
setupPublicQuote(apiJSON);
render();
refreshSession();
